package TermProject;

import java.util.*;

public class AutoPark {
	private ArrayList<SubscribedVehicle> subscribedVehicle;
	private ParkRecord parkRecords[];
	private double hourlyFee, incomeDaily;
	private int incomeDailyDate;

	public AutoPark(double hourlyFee, int capacity) {
		this.hourlyFee = hourlyFee;
		parkRecords = new ParkRecord[capacity];
		subscribedVehicle = new ArrayList<SubscribedVehicle>();
		this.incomeDaily = 0;
		this.incomeDailyDate = Date.getToday().getDay();
	}

	public SubscribedVehicle searchVehicle(String plate) {
		for (SubscribedVehicle vehicle : subscribedVehicle) {
			if (vehicle.getPlate() == plate) {
				return vehicle;
			}
		}
		return null;
	}

	public boolean isParked(String plate) {
		for (int i = 0; i < parkRecords.length; i++) {
			if(parkRecords[i]!=null) {
			if (parkRecords[i].getVehicle().getPlate() == plate) {
				return true;
			}
		}}
		return false;
	}

	public void enlargeVehicleArray() {
		Scanner in = new Scanner(System.in);
		System.out.println("Yeni kapasite giriniz:");
		int yeni = in.nextInt();
		in.close();

		if (yeni <= parkRecords.length) {
			return;
		}
		ParkRecord gecicidizi[] = new ParkRecord[yeni];
		for (int i = 0; i < parkRecords.length; i++) {
			gecicidizi[i] = parkRecords[i];

		}
		parkRecords = gecicidizi;
	}

	public boolean addVehicle(SubscribedVehicle vehicle) {
		if (vehicle.getSubscription() == null) {
			return false;
		}
		for (SubscribedVehicle veh : subscribedVehicle) {
			if (veh.getPlate() == vehicle.getPlate()) {
				return false;
			}
		}
		subscribedVehicle.add(vehicle);
		return true;

	}

	public boolean vehicleEnters(String plate, Time enter, boolean isOfficial) {
		if (this.isParked(plate) == true) {
			return false;
		} // Plakas� verilen ara� zaten otoparkta
if(this.searchVehicle(plate)!=null) {
		if (this.searchVehicle(plate).getPlate() == plate) {
			int i;
			for (i = 0; i < parkRecords.length; i++) {
				if (parkRecords[i] == null) {
					parkRecords[i] = new ParkRecord(enter, this.searchVehicle(plate));
					return true;
				}
			}
			System.out.println("Otopark dolu");
			return false;
		}}

		if (isOfficial == true) {
			int i;
			for (i = 0; i < parkRecords.length; i++) {
				if (parkRecords[i] == null) {
					parkRecords[i] = new ParkRecord(enter, new OfficialVehicle(plate));
					return true;
				}
			}
			System.out.println("Otopar dolu");
			return false;
		} else {
			int i;
			for (i = 0; i < parkRecords.length; i++) {
				if (parkRecords[i] == null) {
					parkRecords[i] = new ParkRecord(enter, new RegularVehicle(plate));
					return true;
				}
			}
			System.out.println("Otopark dolu");
			return false;
		}
	}

	public boolean vehicleExits(String plate, Time exit) {
		for (int i = 0; i < parkRecords.length; i++) {
			if(parkRecords[i]!=null) {
			if (parkRecords[i].getVehicle().getPlate() == plate) {
				parkRecords[i].setExitTime(exit);
				parkRecords[i].setExitDay(Date.getToday().getDay());
				if (parkRecords[i].getVehicle().isSpecial() == true) {
					parkRecords[i] = null;
					return true;
				} else if (parkRecords[i].getVehicle().getSubscription() != null) {
					if (parkRecords[i].getVehicle().getSubscription().isValid() == true) {
						parkRecords[i] = null;
						return true;
					} else {
						// isvalid false geldi. bittikten sonraki �creti al.
						Time time = new Time(0, 0);
						if(parkRecords[i].getEnterDay()<parkRecords[i].getVehicle().getSubscription().getEnd().getDay()&&parkRecords[i].getEnterDay()>parkRecords[i].getVehicle().getSubscription().getBegin().getDay()){
							parkRecords[i].setEnterTime(time);
						parkRecords[i].setEnterDay(parkRecords[i].getVehicle().getSubscription().getEnd().getDay() + 1);}
						if (parkRecords[i].getParkingDuration() >= 0 && parkRecords[i].getParkingDuration() <= 55) {
							parkRecords[i] = null;
							return true;
						} else if (parkRecords[i].getParkingDuration() > 55 && parkRecords[i].getParkingDuration() <= 95) {
							this.controlIncomeDailyDate();
							incomeDaily += 1 * hourlyFee;
							parkRecords[i] = null;
							return true;
						} else {
							if (parkRecords[i].getParkingDuration() % 60 == 0) {
								this.controlIncomeDailyDate();
								incomeDaily += (parkRecords[i].getParkingDuration() / 60) * hourlyFee;
							} else {
								this.controlIncomeDailyDate();
								incomeDaily += (parkRecords[i].getParkingDuration() / 60 + 1) * hourlyFee;
							}
							parkRecords[i] = null;
							return true;

						}
					}
				} else {
					if (parkRecords[i].getParkingDuration() >= 0 && parkRecords[i].getParkingDuration() <= 55) {
						parkRecords[i] = null;
						return true;
					} else if (parkRecords[i].getParkingDuration() > 55 && parkRecords[i].getParkingDuration() <= 95) {
						this.controlIncomeDailyDate();
						incomeDaily += 1 * hourlyFee;
						parkRecords[i] = null;
						return true;
					} else {
						if (parkRecords[i].getParkingDuration() % 60 == 0) {
							this.controlIncomeDailyDate();
							incomeDaily += (parkRecords[i].getParkingDuration() / 60) * hourlyFee;
						} else {
							this.controlIncomeDailyDate();
							incomeDaily += (parkRecords[i].getParkingDuration() / 60 + 1) * hourlyFee;
						}
						parkRecords[i] = null;
						return true;
					}
				}
			}}
		}
		System.out.println("Otoparkta plakas� verilen ara� bulunamad�.");
		return false;
	}

	public void controlIncomeDailyDate(){
		int today = Date.getToday().getDay();
		if (this.incomeDailyDate != today) {
			this.incomeDaily = 0;
			this.incomeDailyDate = today;
		}
	}

	public String toString() {
		String intro = "Otopark�n saatlik �creti: " + hourlyFee;
		intro += "  Otopark�n g�nl�k geliri: " + incomeDaily;
		intro+="  Otopark�n kapasitesi="+parkRecords.length;
		intro+="  Otoparka kay�tl� ara� say�s�="+subscribedVehicle.size();
		return intro;
	}

}
