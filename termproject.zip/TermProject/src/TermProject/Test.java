package TermProject;

public class Test {

	public static void main(String[] args) {
		// Time s�n�f� i�in deneme
		Time enterTime = new Time(10, 0);
		Time exitTime = new Time(11, 30);
		System.out.println("10:00-11:30 aras�ndaki saat fark�: " + exitTime.getDifference(enterTime));

		// Date s�n�f� i�in deneme
		Date date1 = new Date(15, 04, 2019);
		Date date2 = new Date(18, 04, 2019);
		Date date3 = new Date(20, 04, 2019);
		Date date4 = new Date(25, 04, 2019);
		if (!date1.isAfterThan(date2)) {
			System.out.println("isAfterThan metodu ba�ar�yla ger�ekle�ti.");
		}
		if (date1.isBeforeThan(date2)) {
			System.out.println("isBeforeThan metodu ba�ar�yla ger�ekle�ti.");
		}
		if (!date1.isEqualWith(date2)) {
			System.out.println("isEqualWith metodu ba�ar�yla ger�ekle�ti.");
		}
		System.out.println("Bug�n:" + Date.getToday().getDay() + "." + Date.getToday().getMonth() + "."
				+ Date.getToday().getYear());

		// Subscription s�n�f� i�in deneme
		Subscription kayit1 = new Subscription(date1, date2);
		Subscription kayit2 = new Subscription(date3, date4);
		if (kayit1.isValid() == true) {
			System.out.println("kay�t hala ge�erli (isValid methodu ba�ar�yla ger�ekle�ti.)");
		}

		// SubscribedVehicle s�n�f� i�in deneme
		SubscribedVehicle kayitliarac1 = new SubscribedVehicle("123");
		SubscribedVehicle kayitliarac2 = new SubscribedVehicle("234");
		kayitliarac1.setSubscription(kayit1); // ara� ya da kay�t �zerinden set i�lemi yapmal�y�m. sadece birinden yapmam yeterli.
		kayit2.setVehicle(kayitliarac2);
		System.out.println("1. ara�=" + kayit1.getVehicle().getPlate());
		System.out.println(kayitliarac1.getSubscription().getEnd().getDay());
		System.out.println("2. ara�=" + kayit2.getVehicle().getPlate());
		System.out.println(kayitliarac2.getSubscription().getEnd().getDay());

		AutoPark otopark= new AutoPark(10,4);
		System.out.println(otopark.toString());
		otopark.addVehicle(kayitliarac1);
		otopark.addVehicle(kayitliarac2);
		System.out.println(otopark.toString());
		if(otopark.searchVehicle("123")==kayitliarac1) {System.out.println("123 plakal� ara� bulundu.");}
		if(otopark.searchVehicle("546")==null) {System.out.println("546 plakal� ara� bulunamad�.");}
		
		SubscribedVehicle kayitliarac3 = new SubscribedVehicle("345");
		otopark.addVehicle(kayitliarac3);//kayd� setlenmemi� ara� bu diziye al�namaz.
		System.out.println(otopark.toString());
		
		otopark.addVehicle(kayitliarac2); //ayn� plakal� ara� diziye tekrar eklenemez.
		System.out.println(otopark.toString());
		
		Time time1= new Time(10,0);
		Time time2= new Time(11,0);
		Time time3= new Time(12,0);
		Time time4= new Time(13,30);
		Time time5= new Time(14,30);
		Time time6= new Time(16,50);
		if(otopark.vehicleEnters("123", time1, false)==true) {System.out.println("123 plakal� ara� otoparka girdi.");} //subscribed vehicle
		if(otopark.vehicleEnters("123", time1, false)==false) {System.out.println("123 plakal� ara� otoparkta bulundu�u i�in tekrar giremedi.");}
		if(otopark.vehicleEnters("234", time2, false)==true) {System.out.println("234 plakal� ara� otoparka girdi.");} //subscribed vehicle
		if(otopark.vehicleEnters("567", time3, false)==true) {System.out.println("567 plakal� ara� otoparka girdi.");} //regular vehicle
		if(otopark.vehicleEnters("678", time4, true)==true) {System.out.println("678 plakal� ara� otoparka girdi.");} //official vehicle
		if(otopark.vehicleEnters("789", time5, false)==false) {System.out.println("789 plakal� ara� otoparka giremedi.");}
		
		//enlargeVehicleArray() metodunu deneyelim.
		otopark.enlargeVehicleArray(); //4'den b�y�k bir de�er girilirse yeni ara� otoparka girer.
		if(otopark.vehicleEnters("789", time5, false)==true) {System.out.println("789 plakal� ara� otoparka girdi.");}
		
		 if(otopark.isParked("123")==true) {System.out.println("123 plakal� ara� otoparkta bulundu.");}
		 if(otopark.isParked("234")==true) {System.out.println("234 plakal� ara� otoparkta bulundu.");}
		 if(otopark.isParked("567")==true) {System.out.println("567 plakal� ara� otoparkta bulundu.");}
		 if(otopark.isParked("789")==true) {System.out.println("789 plakal� ara� otoparkta bulundu.");}
		 else {System.out.println("789 plakal� ara� otoparkta bulunamad�.");}
		 if(otopark.isParked("963")==false) {System.out.println("963 plakal� ara� otoparkta bulunamad�.");}
		 
		 //ilk 55 dakika �cretsiz
		 //95 dakikaya (1 saat 35 dakika) kadar 1 saatlik �cret al�nacak
		 //95dakikadan sonra saat bir �ste yuvarlanacak. �rne�in 1 saat 40 dakika kalan bir arabadan 2 saatlik �cret al�nacakt�r.
		 if(otopark.vehicleExits("123", time4)==true) {System.out.println("123 plakal� ara� otoparktan ��kt�.");} //isValid de�eri true oldu�u i�in kay�tl� ara�tan �cret al�nmad�.
		 System.out.println(otopark.toString());
		
		 if(otopark.vehicleExits("234", time5)==true) {System.out.println("234 plakal� ara� otoparktan ��kt�.");}
		 System.out.println(otopark.toString());
		 
		 if(otopark.vehicleExits("567", time4)==true) {System.out.println("567 plakal� ara� otoparktan ��kt�.");}
		 System.out.println(otopark.toString());
		 
		 if(otopark.vehicleExits("678", time6)==true) {System.out.println("678 plakal� ara� otoparktan ��kt�.");}
		 System.out.println(otopark.toString());
		 
		 if(otopark.vehicleExits("698", time6)==false) {System.out.println("698 plakal� ara� otoparkta mevcut de�il.");}
		 System.out.println(otopark.toString());
		 
		 if(otopark.vehicleExits("789", time6)==true) {System.out.println("789 plakal� ara� otoparktan ��kt�.");}
		 System.out.println(otopark.toString());
		 
		 
	}
}
