package TermProject;

import static org.junit.Assert.*;

import org.junit.Test;

public class DateTest {

	@Test
	public void testEqual() {
		Date day1= new Date(17,4,2019);
		Date day2= new Date(23,6,2019);
		boolean control=day1.isEqualWith(day2);
		assertEquals(false,control);
	}
	
	@Test
	public void testAfter() {
		Date day1= new Date(17,4,2019);
		Date day2= new Date(23,6,2019);
		boolean control=day1.isAfterThan(day2);
		assertEquals(false,control);
	}
	
	@Test
	public void testBefore() {
		Date day1= new Date(17,4,2019);
		Date day2= new Date(23,6,2019);
		boolean control=day1.isBeforeThan(day2);
		assertEquals(true,control);
	}
	
	@Test
	public void testToday() {
		Date day1= new Date(17,4,2019);
		Date today=new Date(Date.getToday().getDay(),Date.getToday().getMonth(),Date.getToday().getYear());
		boolean control=day1.isBeforeThan(today);
		
		assertEquals(false,control);
	}

	
}
