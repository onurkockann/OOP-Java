package TermProject;

public class SubscribedVehicle implements Vehicle {
	private String plate;
	private Subscription subscription;
	
	
	public SubscribedVehicle(String plate) {
		this.plate = plate;
		this.subscription=null;
	}

	public void setSubscription(Subscription subscription) {
		this.subscription = subscription;
		if(subscription.getVehicle()!=this) {
		subscription.setVehicle(this);}
	}

	public String getPlate(){
		return plate;
	}
	
	public Subscription getSubscription(){
		return subscription;
	}
	
	
	public boolean isSpecial(){
		return false;
	}
	 

}
