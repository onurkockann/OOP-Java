package TermProject;

public class Subscription {
private Date begin;
private Date end;
private SubscribedVehicle vehicle;

public Subscription(Date begin, Date end) {
	this.begin = begin;
	this.end = end;
	this.vehicle=null;
}
 
public boolean isValid() {
	Date today= new Date();
	today=Date.getToday();
	if(this.end.isAfterThan(today)&&this.begin.isBeforeThan(today)||this.end.isEqualWith(today)||this.begin.isEqualWith(today)) {return true;} 
	return false;
	
}

public SubscribedVehicle getVehicle() {
	return vehicle;
}

public void setVehicle(SubscribedVehicle vehicle) {
	this.vehicle = vehicle;
	if(vehicle.getSubscription()!=this) {
	vehicle.setSubscription(this);}
}

public Date getBegin() {
	return begin;
}

public Date getEnd() {
	return end;
}

}


