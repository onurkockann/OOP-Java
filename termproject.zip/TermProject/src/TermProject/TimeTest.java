package TermProject;

import static org.junit.Assert.*;

import org.junit.Test;

public class TimeTest {
	
	@Test
	public void testDifference() {
		Time time1= new Time(18,0);
		Time time2= new Time(21,40);
	int actual=time2.getDifference(time1);
	int expected= 220;
	assertEquals(expected,actual);
	}

}
