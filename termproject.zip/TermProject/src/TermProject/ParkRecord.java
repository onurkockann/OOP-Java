package TermProject;

public class ParkRecord {
	private Time enterTime, exitTime;
	private int enterDay, exitDay;
	private Vehicle vehicle;

	public ParkRecord(Time enterTime, Vehicle vehicle) {
		this.enterTime = enterTime;
		this.vehicle = vehicle;
		this.exitTime = null;
		this.enterDay = Date.getToday().getDay();
	}

	public int getParkingDuration() {
		if (enterDay == exitDay) {
			return exitTime.getDifference(enterTime);
		} else {
			if (exitTime.getHour() > enterTime.getHour()) {
				return (exitDay - enterDay) * 24 * 60 + exitTime.getDifference(enterTime);
			} else if (exitTime.getHour() < enterTime.getHour()) {
				return (exitDay - enterDay - 1) * 24 * 60 + exitTime.getDifference(enterTime);
			} else {
				if (exitTime.getMinute() >= enterTime.getMinute()) {
					return (exitDay - enterDay) * 24 * 60 + exitTime.getDifference(enterTime);
				} else {
					return (exitDay - enterDay - 1) * 24 * 60 + exitTime.getDifference(enterTime);
				}
			}
		}
	}

	public Time getEnterTime() {
		return enterTime;
	}

	public Time getExitTime() {
		return exitTime;
	}

	public void setEnterTime(Time enterTime) {
		this.enterTime = enterTime;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setExitTime(Time exitTime) {
		this.exitTime = exitTime;
	}

	public int getEnterDay() {
		return enterDay;
	}

	public void setEnterDay(int enterDay) {
		this.enterDay = enterDay;
	}

	public int getExitDay() {
		return exitDay;
	}

	public void setExitDay(int exitDay) {
		this.exitDay = exitDay;
	}

}
