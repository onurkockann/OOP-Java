package TermProject;

import java.util.Calendar;

public class Date {
	private int day, month, year;

	public Date(int day, int month, int year) {
		this.day = day;
		this.month = month;
		this.year = year;
	}
	

	public Date() {
	}


	public boolean isAfterThan(Date other) {
		if (this.year > other.getYear()) {
			return true;
		}
		else if (this.year == other.getYear()) {
			if (this.month > other.getMonth()) {
				return true;
			}
			else if (this.month == other.getMonth()) {
				if (this.day > other.getDay()) {
					return true;
				}
				else if (this.day == other.getDay()) {
					return false;
				}
			}
		}
		return false;
	}

	public boolean isBeforeThan(Date other) {
		 if(this.year<other.getYear()){
             return true;
  }
  else if(this.year==other.getYear()){
             if(this.month<other.getMonth()){
                       return true;
             }
             else if(this.month==other.getMonth()){
                       if(this.day<other.getDay()){
                                  return true;
                       }
                       else if(this.day==other.getDay()){
                                  return false;
                       }
             }
  }
  return false;
	}

	public boolean isEqualWith(Date other) {
		 if(this.year==other.getYear()){
             if(this.month==other.getMonth()){
                       if(this.day==other.getDay()){
                                  return true;
                       }
             }
  }
  return false;
	}

	public static Date getToday() {
		Calendar cal = Calendar.getInstance();
		int day = cal.get(Calendar.DAY_OF_MONTH);
		int month = cal.get(Calendar.MONTH);
		int year = cal.get(Calendar.YEAR);

		Date date = new Date(day, month, year);
		return date;
	}

	public int getDay() {
		return day;
	}

	public int getMonth() {
		return month;
	}

	public int getYear() {
		return year;
	}
	
	
}
